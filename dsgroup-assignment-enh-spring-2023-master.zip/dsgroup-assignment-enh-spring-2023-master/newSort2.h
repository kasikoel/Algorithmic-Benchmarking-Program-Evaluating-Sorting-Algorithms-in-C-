#pragma once
#ifndef new_Sort2
#define new_Sort2

void insertionSort(int arr[], int left, int right);
void merge(int arr[], int l, int r);
void timSort(int arr[], int n);

#endif