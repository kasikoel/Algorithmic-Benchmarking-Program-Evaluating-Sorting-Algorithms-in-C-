#pragma once


#ifndef Ssort_H
#define Ssort_H

#include <vector>

void bubbleSort(int arr[], int n);
void selectionSort(int arr[], int n);
void swap(int* xp, int* yp);

#endif
